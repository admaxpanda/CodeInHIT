#include <stdio.h>
int main()
{
    int n;
    scanf("%d",&n);
    printf("sum = %d",n*(n+1)/2);
    return 0;
}
