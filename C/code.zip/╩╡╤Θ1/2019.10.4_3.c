#include <stdio.h>
int main()
{
    printf("*****************************\n\n         Very   Good\n\n*****************************\n");
    return 0;
}
